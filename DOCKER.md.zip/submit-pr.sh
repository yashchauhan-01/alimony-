#!/usr/bin/env bash
# Usage: ./submit-pr.sh <your-github-username>
# Run it in the folder that contains alimony-integration.patch and alimony-rag-api.patch.
# Prerequisite: you have already clicked "Fork" on https://github.com/mohitraj8503/Alimony-Plus
set -euo pipefail
USER_NAME="${1:?usage: ./submit-pr.sh <your-github-username>}"
UPSTREAM_URL="${UPSTREAM_URL:-https://github.com/mohitraj8503/Alimony-Plus.git}"
FORK_URL="${FORK_URL:-https://github.com/${USER_NAME}/Alimony-Plus.git}"
BRANCH="feature/yash-integration-rag-api"
HERE="$(cd "$(dirname "$0")" && pwd)"
for p in alimony-integration.patch alimony-rag-api.patch; do
  [ -f "$HERE/$p" ] || { echo "missing $p next to this script"; exit 1; }
done

WORK="$(mktemp -d)"; cd "$WORK"
git clone "$FORK_URL" Alimony-Plus && cd Alimony-Plus
git remote add upstream "$UPSTREAM_URL" 2>/dev/null || true
git fetch upstream main
git checkout -b "$BRANCH" upstream/main              # start from the mentor's latest main

PATCHES=("$HERE/alimony-integration.patch" "$HERE/alimony-rag-api.patch")
[ -f "$HERE/alimony-docker.patch" ] && PATCHES+=("$HERE/alimony-docker.patch")   # optional: only after you have run docker compose yourself
git apply --check "${PATCHES[@]}"
for p in "${PATCHES[@]}"; do git apply --index "$p"; done
git status --short | grep -E "\.env$|node_modules|uploads/" && { echo "refusing: secrets/junk staged"; exit 1; } || true

git commit -q -m "Integration: intake, document checklist, legal-route navigator, security hardening; add FastAPI + pgvector RAG service"
git push -u origin "$BRANCH"
echo
echo "Pushed. Open the pull request here:"
echo "https://github.com/mohitraj8503/Alimony-Plus/compare/main...${USER_NAME}:Alimony-Plus:${BRANCH}?expand=1"
